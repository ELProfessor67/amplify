export const WebRTCTransportConfig = {
    iceServers: [
        {
          urls: [
            'stun.gmx.net:3478',
            'stun.gradwell.com:3478'
          ]
        }
      ]
}
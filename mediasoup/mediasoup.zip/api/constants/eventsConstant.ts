export const JOIN_ROOM = "event:join-room";
export const MESSAGE = "event:chat-message";
export const redisChannel = 'chat-channel';
